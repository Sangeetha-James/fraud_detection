Fraud Detection Case Study Submission

Contents:
- Fraud_detection.ipynb : Complete Jupyter Notebook containing data cleaning,
  feature engineering, model development, evaluation, and answers to all
  business questions (1–8).

Tools & Technologies:
- Python
- Pandas, NumPy
- Scikit-learn
- XGBoost
- Matplotlib, Seaborn

Objective:
Proactive detection of fraudulent financial transactions using machine learning
and actionable business insights.
